BuxtehudeRP – HTML5 Webseite

1. index.html im Browser öffnen.
2. Die Seite ist eine eigenständige HTML5-Datei.
3. Der Discord-Button ist aktuell ein Platzhalter (#). Trage dort später deinen Discord-Einladungslink ein.
4. Für Google Sites kann eine komplette HTML-Datei nicht direkt als Site importiert werden; sie kann separat gehostet und anschließend eingebettet/verlinkt werden.
